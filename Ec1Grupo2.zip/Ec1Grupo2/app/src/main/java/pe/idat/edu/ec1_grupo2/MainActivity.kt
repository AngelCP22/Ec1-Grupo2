package pe.idat.edu.ec1_grupo2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import pe.idat.edu.ec1_grupo2.databinding.ActivityMainBinding
import kotlin.math.roundToInt
import kotlin.math.roundToLong

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(saveInstanceState: Bundle?){
        super.onCreate(saveInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnCalcular.setOnClickListener(this)

    }

    override fun onClick(p0: View?) {
        calcularPromedio()
    }

    private fun calcularPromedio() {
        var n1 = binding.txtNota1.text.toString().toDouble()
        var n2 = binding.txtNota2.text.toString().toDouble()
        var n3 = binding.txtNota3.text.toString().toDouble()
        var n4 = binding.txtNota4.text.toString().toDouble()

        var pro = 0.0

        if((n1 <= n2) && (n1 <= n3) && (n1 <= n4)){

            pro = (n2*0.2)+(n3*0.3)+(n4*0.5)

        }else if((n2 <= n1) && (n2 <= n3) && (n2 <= n4)){
            pro = (n1*0.2)+(n3*0.3)+(n4*0.5)
        }else if((n3 <= n1) && (n3 <= n2) && (n3 <= n4)){
            pro = (n1*0.2)+(n2*0.3)+(n4*0.5)
        }else if((n4 <= n1) && (n4 <= n2) && (n4 <= n3)){
            pro = (n1*0.2)+(n2*0.3)+(n3*0.5)
        }


        binding.txtPromedio.text = "El promedio es : ${pro} \n El promedio redondeado es : ${pro.roundToLong()} "


    }


}